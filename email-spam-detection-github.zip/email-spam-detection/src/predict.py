"""Load a trained model and classify a message."""
from pathlib import Path
import sys
import joblib

ROOT = Path(__file__).resolve().parents[1]
MODEL_PATH = ROOT / "models" / "spam_model.joblib"


def load_model():
    if not MODEL_PATH.exists():
        raise FileNotFoundError(
            "Trained model not found. Run `python -m src.train` first."
        )
    return joblib.load(MODEL_PATH)


def predict_message(message: str) -> dict:
    """Return predicted label and class probabilities."""
    if not isinstance(message, str) or not message.strip():
        raise ValueError("Please provide a non-empty message.")
    model = load_model()
    label = str(model.predict([message])[0])
    probabilities = model.predict_proba([message])[0]
    classes = model.named_steps["classifier"].classes_
    scores = {str(name): float(score) for name, score in zip(classes, probabilities)}
    return {"label": label, "confidence": scores.get(label, 0.0), "probabilities": scores}


def main():
    if len(sys.argv) < 2:
        print('Usage: python -m src.predict "Paste your message here"')
        raise SystemExit(2)
    result = predict_message(" ".join(sys.argv[1:]))
    print(f"Prediction: {result['label'].upper()}")
    print(f"Model confidence: {result['confidence']:.1%}")
    print("Reminder: this is a demo model and can be wrong.")


if __name__ == "__main__":
    main()
