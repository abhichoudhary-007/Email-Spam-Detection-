"""Train and save the email spam classification pipeline."""
from pathlib import Path
import joblib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import accuracy_score, classification_report
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "emails.csv"
MODEL_PATH = ROOT / "models" / "spam_model.joblib"


def load_data(path: Path = DATA_PATH) -> pd.DataFrame:
    """Load and validate the CSV dataset."""
    df = pd.read_csv(path)
    required = {"text", "label"}
    if not required.issubset(df.columns):
        raise ValueError("Dataset must contain 'text' and 'label' columns.")
    df = df.dropna(subset=["text", "label"]).copy()
    df["text"] = df["text"].astype(str).str.strip()
    df["label"] = df["label"].astype(str).str.lower().str.strip()
    df = df[df["label"].isin(["spam", "ham"])]
    df = df[df["text"] != ""]
    if df["label"].nunique() < 2:
        raise ValueError("Dataset must include both 'spam' and 'ham' labels.")
    if len(df) < 6:
        raise ValueError("Add at least 6 labelled examples before training.")
    return df


def build_pipeline() -> Pipeline:
    """Create a simple text-classification pipeline."""
    return Pipeline([
        ("tfidf", TfidfVectorizer(lowercase=True, stop_words="english")),
        ("classifier", MultinomialNB()),
    ])


def train_model() -> tuple[Pipeline, dict]:
    df = load_data()
    X_train, X_test, y_train, y_test = train_test_split(
        df["text"], df["label"], test_size=0.25, random_state=42,
        stratify=df["label"]
    )
    model = build_pipeline()
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    metrics = {
        "accuracy": float(accuracy_score(y_test, predictions)),
        "report": classification_report(y_test, predictions, zero_division=0),
        "test_size": int(len(y_test)),
    }
    MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, MODEL_PATH)
    return model, metrics


if __name__ == "__main__":
    _, results = train_model()
    print(f"Model saved to: {MODEL_PATH}")
    print(f"Holdout accuracy: {results['accuracy']:.3f}")
    print(f"Test examples: {results['test_size']}")
    print(results["report"])
    print("Note: the included sample is small; these metrics are not production estimates.")
