"""Basic tests for dataset validation and pipeline construction."""
import unittest
from pathlib import Path
from src.train import load_data, build_pipeline, DATA_PATH


class SpamProjectTests(unittest.TestCase):
    def test_dataset_has_required_columns_and_both_labels(self):
        data = load_data(DATA_PATH)
        self.assertIn("text", data.columns)
        self.assertIn("label", data.columns)
        self.assertEqual(set(data["label"].unique()), {"spam", "ham"})

    def test_pipeline_has_expected_steps(self):
        pipeline = build_pipeline()
        self.assertEqual(list(pipeline.named_steps.keys()), ["tfidf", "classifier"])


if __name__ == "__main__":
    unittest.main()
