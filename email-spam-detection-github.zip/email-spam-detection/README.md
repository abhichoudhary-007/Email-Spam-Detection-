# Email Spam Detection

A beginner-friendly machine learning project that classifies an email or message as **Spam** or **Not Spam (Ham)** using TF-IDF features and a Multinomial Naive Bayes classifier.

> **Educational demo:** The included dataset is a small illustrative sample, not a production-grade training corpus. Do not use this model as the sole basis for security or business decisions.

## Features
- Text preprocessing with scikit-learn TF-IDF
- Multinomial Naive Bayes classifier
- Train and evaluate from a CSV dataset
- Command-line prediction
- Optional Streamlit web interface
- Saved model pipeline
- Basic unit tests

## Project structure
```text
email-spam-detection/
├── app.py
├── data/
│   └── emails.csv
├── models/                 # created after training
├── src/
│   ├── __init__.py
│   ├── predict.py
│   └── train.py
├── tests/
│   └── test_predict.py
├── .gitignore
├── LICENSE
├── requirements.txt
└── README.md
```

## 1. Requirements
- Python 3.10 or newer
- pip

## 2. Set up a virtual environment
Windows:
```bash
python -m venv .venv
.venv\\Scripts\\activate
```
macOS/Linux:
```bash
python3 -m venv .venv
source .venv/bin/activate
```

Install dependencies:
```bash
pip install -r requirements.txt
```

## 3. Train the model
From the project root:
```bash
python -m src.train
```
This writes the trained pipeline to `models/spam_model.joblib` and prints evaluation metrics. Metrics on this tiny sample are only for demonstrating the workflow.

## 4. Predict from the command line
Train first, then run:
```bash
python -m src.predict "Congratulations! You have won a free prize. Claim now."
python -m src.predict "Hi, are we still meeting for lunch tomorrow?"
```

## 5. Run the web app (optional)
```bash
streamlit run app.py
```
Paste an email/message into the text box and select **Check message**.

## Dataset format
`data/emails.csv` must contain:
- `text`: email/message body
- `label`: `spam` or `ham`

To improve the project, use a larger, legally obtained, appropriately licensed dataset (for example, a public SMS spam dataset) and document its source and license. Keep a separate test set and avoid reporting results from the training data as general performance.

## Limitations and safety
- The sample dataset is deliberately small and cannot represent all spam patterns.
- The model may make false-positive and false-negative predictions.
- Do not paste confidential or personal emails into a demo app.
- This project classifies message text only; it does not inspect links, attachments, sender reputation, or email headers.

## GitHub upload
1. Create a new empty repository on GitHub named `email-spam-detection`.
2. Extract this ZIP.
3. In the extracted folder, initialize and push:
   ```bash
   git init
   git add .
   git commit -m "Add email spam detection project"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/email-spam-detection.git
   git push -u origin main
   ```
4. Replace `YOUR-USERNAME` with your GitHub username.

Never upload passwords, API keys, private emails, or virtual-environment folders.
