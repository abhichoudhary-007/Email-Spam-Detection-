"""Optional Streamlit user interface."""
import streamlit as st
from src.predict import MODEL_PATH, predict_message

st.set_page_config(page_title="Email Spam Detector", page_icon="📧")
st.title("📧 Email Spam Detector")
st.write("Enter a message to estimate whether it looks like spam.")
st.warning("Demo only: the model is trained on a small sample and may be wrong. Avoid entering private emails.")

if not MODEL_PATH.exists():
    st.info("The model has not been trained yet. Run `python -m src.train` in the terminal first.")
else:
    message = st.text_area("Email or message text", height=180,
                           placeholder="Paste the message text here...")
    if st.button("Check message", type="primary"):
        if not message.strip():
            st.error("Please enter some text first.")
        else:
            try:
                result = predict_message(message)
                if result["label"] == "spam":
                    st.error(f"Likely SPAM — model confidence {result['confidence']:.1%}")
                else:
                    st.success(f"Likely NOT SPAM — model confidence {result['confidence']:.1%}")
                st.caption("Confidence is the model's estimated class probability, not a guarantee.")
                with st.expander("View class probabilities"):
                    st.json(result["probabilities"])
            except Exception as exc:
                st.error(f"Prediction failed: {exc}")
